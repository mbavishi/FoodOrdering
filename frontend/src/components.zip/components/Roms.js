import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from "./Home";
import NoPage from "./NoPage";
import Customer from "./Customer";
import MenuAdmin from "./MenuAdmin";
import AboutUs from "./AboutUs";
import Contact from "./Contact";
import Layout from "./theme/layout";
import CategoryLayout from "./CategoryLayout";

function Roms() {
  return (
    <>
      <Layout>
        <main>
          <Routes>
            <Route index element={<Home />} />
            <Route path="/customer" element={<Customer />} />
            <Route path="/menu_customer" element={<CategoryLayout />} />
            <Route path="/menu_admin" element={<MenuAdmin />} />
            <Route path="/about" element={<AboutUs />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NoPage />} />
          </Routes>
        </main>
      </Layout>
    </>
  );
}

export default Roms;
